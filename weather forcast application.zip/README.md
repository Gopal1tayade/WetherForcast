*****this is the web application that provide the wether condition of the current location and the city you want*****

# to run this application download the zip file or clone the project by using the url "https://github.com/Gopal1tayade/WetherForcast.git"

# downloade all the dependancy for it by using the  ' npm install '
 # once all done open the clone project withe live server or copy the project url and past it on the browser             

***** then you see working of the application *****




# git url for this application -----> " https://github.com/Gopal1tayade/WetherForcast "
